from django.shortcuts import render, get_object_or_404
from django.views.generic.base import View

from .models import Category, Product
from pure_pagination import Paginator, EmptyPage, PageNotAnInteger
from cart.forms import CartAddProductForm


def home(request):
    categories = Category.objects.all()
    products = Product.objects.filter(available=True)[:9]
    content = { 'categories': categories,'products': products}

    return render(request, 'shop/home.html', content)


class ProductsView(View):   #所有产品视图
    def get(self, request, category_slug=None):
        category = None
        categories = Category.objects.all()
        products = Product.objects.filter(available=True)

        if category_slug:
            category = get_object_or_404(Category, slug=category_slug)
            products = products.filter(category=category)
        #用django pure_pagination来实现商品分页
        try:
            page = request.GET.get('page',1)
        except PageNotAnInteger:
            page = 1
        #设定为每页6件商品
        p = Paginator(products, 6, request=request)
        perpage_products = p.page(page)

        return render(request, 'shop/product/list.html', {'category': category,'categories': categories, 'products': perpage_products})


class ProductView(View):  #单个产品视图
    def get(self, request, id, slug):
        product = get_object_or_404(Product, id=id, slug=slug)
        cart_product_form = CartAddProductForm()
        return render(request, 'shop/product/detail.html', {'product': product, 'cart_product_form': cart_product_form})

