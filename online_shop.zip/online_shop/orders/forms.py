from django import forms
from .models import Order


class OrderCreateForm(forms.ModelForm):  #表单来收集用户的信息
    class Meta:
        model = Order
        fields = ['name', 'email', 'address', 'city']